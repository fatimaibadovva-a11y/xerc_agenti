import os
import time
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Xərc Agenti", page_icon="💰", layout="wide")

# API açarı: Streamlit Cloud-da "Secrets"-dən, lokalda mühit dəyişənindən götürülür
try:
    for key in ("ANTHROPIC_API_KEY", "ANTHROPIC_WORKSPACE_ID", "MODEL"):
        if key in st.secrets and not os.environ.get(key):
            os.environ[key] = str(st.secrets[key])
except Exception:
    pass  # secrets faylı yoxdur (lokal işə salma)

if not os.environ.get("ANTHROPIC_API_KEY"):
    st.error("ANTHROPIC_API_KEY tapılmadı. Streamlit Cloud-da: App settings → Secrets bölməsinə əlavə edin.")
    st.stop()

import agent_core as core  # noqa: E402  (açar təyin olunandan SONRA import olunmalıdır)
IDLE_TIMEOUT = 300   # saniyə: fəaliyyət olmasa söhbət bağlanır və yaddaşa yazılır

ss = st.session_state
ss.setdefault("conversation", [])     # QISAMÜDDƏTLİ YADDAŞ (API mesajları)
ss.setdefault("display", [])          # ekranda görünən mesajlar
ss.setdefault("last_active", None)


def archive(notice):
    """Söhbəti bağla: xülasəni uzunmüddətli yaddaşa yaz, qısamüddətli yaddaşı sıfırla."""
    summary = core.archive_conversation(ss.conversation)
    ss.conversation = []
    ss.last_active = None
    ss.display.append({"role": "assistant", "tools": [],
                       "content": f"{notice}\n\n🧠 **Yaddaşa yazıldı:**\n\n{summary or '—'}"})


def pair_tools(tool_log):
    """['🔧 ...', '   ↳ nəticə: ...'] → [(çağırış, nəticə), ...]"""
    pairs, call = [], None
    for line in tool_log:
        if line.startswith("🔧"):
            call = line
        elif call:
            pairs.append((call, line.strip().removeprefix("↳ nəticə:").strip()))
            call = None
    return pairs


def expenses_df():
    rows = [{"id": e["id"], "məbləğ": e["amount"], "kateqoriya": e["category"],
             "qeyd": e["note"], "tarix": e["date"][:16].replace("T", " ")} for e in core.DB["expenses"]]
    return pd.DataFrame(rows, columns=["id", "məbləğ", "kateqoriya", "qeyd", "tarix"])


def budget_line():
    b = core.DB["budget"]
    if b["amount"] is None:
        return "**Büdcə:** limit təyin edilməyib."
    spent = sum(e["amount"] for e in core._expenses_in(b["period"]))
    status = "⚠️ AŞILIB" if spent > b["amount"] else "✅ normal"
    return f"**Büdcə ({b['period']}):** {spent:.2f} / {b['amount']} AZN — {status}"


# ---------------- YAN PANEL: hər 3 san. yenilənir və vaxtı yoxlayır ----------------
@st.fragment(run_every=3)
def side_panel():
    if ss.conversation and ss.last_active and time.time() - ss.last_active > IDLE_TIMEOUT:
        archive(f"⏱ *Söhbət {IDLE_TIMEOUT} saniyə fəaliyyətsizlikdən sonra bağlandı.*")
        st.toast("⏱ Söhbət bağlandı və yaddaşa yazıldı")
        st.rerun()

    if ss.conversation and ss.last_active:
        left = max(0, int(IDLE_TIMEOUT - (time.time() - ss.last_active)))
        st.success(f"🟢 Aktiv söhbət — {left} san. sonra bağlanacaq")
    else:
        st.info("⚪ Aktiv söhbət yoxdur")

    st.markdown(budget_line())
    st.dataframe(expenses_df(), hide_index=True)
    with st.expander("🧠 Uzunmüddətli yaddaş (son 3)"):
        mems = core.load_memories()[-3:]
        if not mems:
            st.caption("Yaddaş boşdur.")
        for m in mems:
            st.markdown(f"**#{m['id']} — {m['date']}**\n\n{m['summary']}")


with st.sidebar:
    st.header("📊 Panel")
    side_panel()
    st.divider()
    if st.button("🔄 Yeni söhbət"):
        if ss.conversation:
            archive("🔄 *Söhbət bağlandı.*")
        st.rerun()
    with st.expander("⚙️ Bazanı sıfırla"):
        st.caption("Bütün xərcləri və uzunmüddətli yaddaşı silir.")
        if st.button("🗑 Hamısını sil", type="secondary"):
            core.reset_all()
            ss.conversation, ss.display, ss.last_active = [], [], None
            st.rerun()
    st.caption("Nümunələr:")
    for ex in ["Bu gün taksiyə 4 manat verdim",
               "Naharda 7 manat xərclədim, bu həftə nə qədər xərclədiyimi de",
               "Bayaq yazdığım xərci 5 manat et",
               "Bir az pul xərclədim",
               "Sabah toya 100 manat salacam",
               "Mənə şeir yaz",
               "Bitir"]:
        if st.button(ex, key=f"ex_{ex}"):
            ss.pending = ex
            st.rerun()

# ---------------- ÇAT ----------------
st.title("💰 Xərc Agenti")
st.caption("Xərclərinizi sərbəst mətnlə yazın. Agent qeyd edir, dəyişir, silir və hesabat verir. "
           "Bitirmək üçün: **bitir**.")

for m in ss.display:
    with st.chat_message(m["role"]):
        for call, result in m.get("tools", []):
            with st.expander(call):
                st.code(result, language="json")
        st.markdown(m["content"])

prompt = st.chat_input("Mesajınızı yazın...") or ss.pop("pending", None)

if prompt:
    ss.display.append({"role": "user", "content": prompt, "tools": []})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Agent düşünür..."):
            try:
                answer, tool_log = core.run_agent_turn(prompt, ss.conversation, verbose=False)
            except Exception as err:
                answer, tool_log = f"Texniki xəta baş verdi: {err}", []
    ss.display.append({"role": "assistant", "content": answer, "tools": pair_tools(tool_log)})
    ss.last_active = time.time()

    if any(l.startswith("🔧 end_chat") for l in tool_log):
        archive("🔚 *Söhbət bitdi.*")

    st.rerun()
