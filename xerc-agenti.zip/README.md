# 💰 Xərc Agenti

**AI Agentlər kursu, Final İmtahan, Variant B**

🌐 **Canlı link:** `https://<sizin-app-adınız>.streamlit.app`

Xərc Agenti sərbəst Azərbaycan dilində yazılmış mesajları başa düşür, xərcləri qeyd edir, dəyişir, silir və hesabat verir. Məsələn:

> 👤 Bu gün naharda 7 manat xərclədim
> 🔧 add_expense çağırıldı: {"amount": 7, "category": "yemək", "note": "nahar"}
> 🤖 7 AZN "yemək" kateqoriyasında qeyd edildi (id: 1).

Agent Python, Streamlit və Anthropic Claude API ilə qurulub.

---

## Fayllar

| Fayl | Məzmun |
|---|---|
| `app.py` | Streamlit interfeysi: çat, yan panel (büdcə, xərc cədvəli, yaddaş), nümunə düymələri |
| `agent_core.py` | Agentin nüvəsi: məlumat bazası, alətlər, alət sxemləri, sistem promptu, agent dövrü, yaddaş |
| `requirements.txt` | Lazım olan Python paketləri |

İşləyərkən agent iki fayl yaradır: `expenses.json` (xərclər və büdcə) və `memory.json` (söhbət xülasələri).

---

## Kursun beş anlayışı

| Anlayış | Necə tətbiq olunub | Harada |
|---|---|---|
| **Sistem promptu** | Rol, məqsəd, alət qaydaları, 6 guardrail, nümunələr, cavab üslubu, yaddaş bölməsi | `agent_core.py` → `build_system_prompt()` |
| **Alətlər** | 6 alət, hansının çağırılacağına model özü qərar verir | `agent_core.py` → `FUNCTIONS`, `TOOLS` |
| **Agent dövrü** | Düşün → alət çağır → nəticəni yoxla → cavab ver (maks. 6 addım) | `agent_core.py` → `run_agent_turn()` |
| **Yaddaş** | Qısamüddətli: söhbət tarixçəsi. Uzunmüddətli: `memory.json`-dakı xülasələr | `app.py` (`st.session_state`), `agent_core.py` |
| **Guardrails** | Prompt qatı və kod qatı (`_check_amount`, `_parse_user_date`) | `agent_core.py` |
| **Bonus** | Büdcə limiti aşılanda ⚠️ xəbərdarlıq | `_budget_warning()` |

---

## Alətlər

| Alət | Nə edir | Giriş | Çıxış |
|---|---|---|---|
| `add_expense` | Yeni xərc qeyd edir | `amount`, `category`, `note` (istəyə görə), `date` (YYYY-MM-DD, istəyə görə) | Qeyd olunmuş xərc (`id` ilə), limit aşılıbsa `warning` |
| `get_summary` | Dövr üzrə hesabat verir | `period`: `bu gün` / `bu həftə` / `bu ay` / `hamısı` | Cəm, kateqoriyalar üzrə bölgü, xərclərin siyahısı |
| `update_expense` | Xərcin məbləğini və ya kateqoriyasını dəyişir | `expense_id`, `amount` və/və ya `category` | Köhnə və yeni qeyd |
| `delete_expense` | Xərci silir | `expense_id` | Silinmiş qeyd |
| `set_budget` | Büdcə limiti təyin edir | `amount`, `period` | Büdcə, lazım gələrsə `warning` |
| `end_chat` | Söhbəti bitirir ("bitir" sözü ilə) | `reason` (istəyə görə) | Status mesajı, xülasə yaddaşa yazılır |

**Kateqoriyalar:** yemək, nəqliyyat, market, əyləncə, kommunal, sağlamlıq, digər.

---

## Guardrails

| Hal | Agentin davranışı |
|---|---|
| "Bir az pul xərclədim" | Məbləği təxmin etmir, dəqiq məbləği soruşur |
| "Sabah toya 100 manat salacam" | Qeyd etmir, bunun plan olduğunu izah edir (kod qatı da gələcək tarixi rədd edir) |
| "Mənə şeir yaz" | Nəzakətlə rədd edir, öz işini xatırladır |
| İnvestisiya, kredit və ya vergi sualı | Məsləhət vermir |
| Qeyri-müəyyən silmə əmri | Silmədən əvvəl soruşur |
| "Sağ ol" | Söhbəti bitirmir, bitirmək üçün "bitir" yazmağı xatırladır |
| Yaddaşdakı mətn | Təlimat kimi yox, məlumat kimi qəbul edilir (prompt injection-a qarşı) |

---

## Yaddaş

- **Qısamüddətli:** hər brauzer sessiyasının öz söhbət tarixçəsi var (`st.session_state`). Ona görə "Bayaq yazdığım xərci 5 manat et" işləyir.
- **Uzunmüddətli:** söhbət bitəndə ("bitir", "Yeni söhbət" düyməsi və ya 300 saniyə fəaliyyətsizlik) model qısa xülasə çıxarır və `memory.json`-a yazır. Növbəti söhbətdə son 5 xülasə sistem promptuna yüklənir.

---

## Lokal işə salma

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY="sk-ant-..."
streamlit run app.py
```

---

## Streamlit Community Cloud-a deploy

1. Bu repo GitHub-da **public** olmalıdır.
2. [share.streamlit.io](https://share.streamlit.io) saytına GitHub hesabı ilə daxil olun.
3. **Create app** → **Deploy a public app from GitHub** seçin:
   - Repository: `<istifadəçi-adınız>/xerc-agenti`
   - Branch: `main`
   - Main file path: `app.py`
   - App URL: istədiyiniz ad, məsələn `xerc-agenti`
4. **Advanced settings** → **Secrets** sahəsinə yazın:
   ```toml
   ANTHROPIC_API_KEY = "sk-ant-..."
   MODEL = "claude-haiku-5-5"
   ```
5. **Deploy** basın. 1–3 dəqiqədən sonra app `https://xerc-agenti.streamlit.app` ünvanında açılacaq.

API açarı **heç vaxt** koda və ya repoya yazılmır, yalnız Secrets bölməsində saxlanılır.

---

## Məhdudiyyətlər

- Bütün ziyarətçilər eyni `expenses.json` bazasını görür. Bu, bir istifadəçi üçün nəzərdə tutulmuş demo versiyadır. Bazanı yan paneldəki **⚙️ Bazanı sıfırla** ilə təmizləmək olar.
- Streamlit Cloud app yenidən başladılanda (yeni commit və ya yuxu rejimindən oyanma) JSON faylları silinir.
- İstifadə olunmayan app bir müddət sonra yuxu rejiminə keçir. Açanda "Wake up" düyməsi ilə oyanır.
- Link public-dir, hər mesaj sizin API açarınızdan xərc çəkir. Anthropic Console-da xərc limiti qoymaq tövsiyə olunur.
